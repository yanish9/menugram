var pathname = window.location.pathname; // Returns path only
var url = window.location.href;


var id = pathname.substring(pathname.lastIndexOf("/") + 1);

var isLogin;

var currentImgId;

$(document).on("click", ".thumbnail", showPicture);


$(document).on("click", ".send", sendComment);

$(document).on("click", "#uploadSubmitter", upload);


function upload() {

    $.post("http://localhost:8080/file-upload" + { wa: "ok", imgid: currentImgId, userid: userID }, function(res) {


    })
}


function sendComment() {


    $.get("http://localhost:8080/currentUser/" + firebase.auth().currentUser.email, function(res) {

        var userID = res[0].id;

        $.post("http://localhost:8080/comments/dish/" + currentImgId, { description: "", imgid: currentImgId, userid: userID }, function(res) {



        })


    });

}

function showPicture() {

    $("#mModal").modal("show");
    console.log($(this).attr("src"));

    $("#image-preview").html("<img src='" + $(this).attr("src") + "'>");

    var currentImgId = $(this).parent().data("id");

    $('#comments-container').comments({
        getComments: function(success, error) {
            var commentsArray = res;
            success(commentsArray);
        }
    });
    $.get("http://localhost:8080/comments/dish/" + $(this).parent().data("id"), function(res) {


    });

    if (isLogin) {


        $(".textarea-wrapper").css({ display: "block" });
    } else {


        //  $(".textarea-wrapper").css({ display: "none" });
    }
}


$.get("http://localhost:8080/res/" + id, function(res) {
    // body... 
    var coo;

    console.log(res);
    for (var i = 0; i < res.length; i++) {
        var col = $(' <div style="width:300px;" class=" col-md-3" data-id="' + res[i].id + '"> ');
        var img = $('<img style="width:300px;" class="thumbnail" src = "' + res[i].img_url + '">')

        var h5 = $('<h5><i class="fa fa-comment" aria-hidden="true"></i></h5>')

        col.append(img, h5);

        $(".images_").append(col);
    }

});

firebase.auth().onAuthStateChanged(function(user) {

    if (user === null) {

        isLogin = false;

    } else {

        isLogin = true;

    }

});